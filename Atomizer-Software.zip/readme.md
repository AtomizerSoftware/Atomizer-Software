# [Atomizer Software](http://atomizersoft.com)

Atomizer Software website

## Features

* [Boilerplate](http://html5boilerplate.com) v3.0.2
* [Sass.](http://sass-lang.com/)

## License

### Major components:

* jQuery: MIT/GPL license
* Modernizr: MIT/BSD license
* Normalize.css: Public Domain

